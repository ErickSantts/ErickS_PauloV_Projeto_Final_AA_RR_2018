#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BRANCO 0
#define CINZA 1
#define PRETO 2

void inicializar_grafo(int n, int **matriz, int *grau, FILE *arquivo)
{
	int conexao;

	for (int i = 0; i < n; i++)
	{
		matriz[i] = (int*) malloc(sizeof(int) * n);
	}

	for (int i = 0; i < n; i++)
	{
		printf("\n");

		for (int j = i; j < n; j++)
		{
			if (i == j)
			{
				matriz[i][j] = 0;
			}
			else
			{
				fscanf(arquivo, "%d", &conexao);

				matriz[i][j] = conexao;
				matriz[j][i] = conexao;

				if (conexao == 1)
				{
					grau[i] = grau[i] + 1;
					grau[j] = grau[j] + 1;
				}
			}
		}
	}
}


int dominacao(int level, int vertice, int n, int *status, int **matriz, int nao_dominado, int dom_temp, int *n_dominantes, int *dominantes)
{
	int *status_temp = (int*) malloc(sizeof(int) * n);

	status[vertice] = PRETO;
	nao_dominado--;
	dom_temp++;

	for (int i = 0; i < n; i++)
	{
		if ((matriz[vertice][i] == 1) && (status[i] == BRANCO))
		{
			status[i] = CINZA;
			nao_dominado--;
		}

		status_temp[i] = status[i];
	}

	if (nao_dominado != 0)
	{
		for (int i = 0; i < n; ++i)
		{
			if (status[i] == CINZA)
			{
				dominacao(level+1, i, n, status, matriz, nao_dominado+1, dom_temp, n_dominantes, dominantes);
				
				for (int j = 0; j < n; j++)
				{
					status[j] = status_temp[j];
				}
			}
		}
	}
	else
	{
		if (dom_temp < *n_dominantes)
		{
			*n_dominantes = dom_temp;

			for (int i = 0; i < n; i++)
			{
				if (status[i] == PRETO)
				{
					dominantes[i] = 1;
				}
				else
				{
					dominantes[i] = 0;
				}
			}
		}
	}

	free(status_temp);

	if (level == 0)
	{
		for (int i = 0; i < n; ++i)
		{
			status[i] = BRANCO;
		}
	}
}

int main()
{
	int n_vertices;
	int *status;
	
	int *n_dominantes;
	int *dominantes;
	int nao_dominado;
	int dom_temp;


	FILE *arquivo;
	int **matriz_adj;
	int *grau;


	// == INICIALIZAR GRAFO ===================================================

	arquivo = fopen("15.txt", "r");

	if (arquivo == NULL)
	{
		printf("ERRO! O arquivo não foi aberto!\n");
	}
	else
	{
		fscanf(arquivo, "%d", &n_vertices);

		matriz_adj = (int**) malloc(sizeof(int*) * n_vertices);
		grau = (int*) malloc(sizeof(int) * n_vertices);
		memset(grau, 0, n_vertices);

		n_dominantes = (int*) malloc(sizeof(int));
		*n_dominantes = n_vertices;

		inicializar_grafo(n_vertices, matriz_adj, grau, arquivo);
	}


	// == INICIALIZAR STATUS DOS VÉRTICES =====================================

	status = (int*) malloc(sizeof(int) * n_vertices);

	memset(status, BRANCO, n_vertices);


	// == INICIALIZAR PROCESSO DE ESCOLHA DO DOMINANTE ========================

	for (int i = 0; i < n_vertices; i++)
	{
		nao_dominado = n_vertices;
		dom_temp = 0;

		dominacao(0, i, n_vertices, status, matriz_adj, nao_dominado, dom_temp, n_dominantes, dominantes);
	}

	printf("Conjunto Dominante = [ ");
	for (int i = 0; i < n_vertices; i++)
	{
		if (dominantes[i] == 1)
		{
			printf("%d ", i);
		}
	}
	printf("]\n");

	return 0;
}